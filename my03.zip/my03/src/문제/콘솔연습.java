package 문제;

import java.util.Scanner;

public class 콘솔연습 {
	public static void main(String[] args) {
	
	}
}
