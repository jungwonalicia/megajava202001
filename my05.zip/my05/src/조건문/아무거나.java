package 조건문;

import java.util.Random;

public class 아무거나 {

	public static void main(String[] args) {
		// 아무거나 내게 하는 class
		// 랜덤(Random) 
		Random	r = new Random();
		int data = r.nextInt(3); //-21억~21억
		//0부터 2까지를 발생시킴. 
		System.out.println(data);
	}
}







