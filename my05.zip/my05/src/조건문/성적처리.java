package 조건문;

public class 성적처리 {

	public static void main(String[] args) {
		// 점수가 88점 이라고 해봅시다.!
		int jumsu = 88;
		
		if (jumsu >= 90) {
			System.out.println("A학점");
		}else {
			 System.out.println("A학점 아님.");
		} 
	}//main end
}//class end
