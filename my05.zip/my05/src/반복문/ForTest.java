package 반복문;

public class ForTest {

	public static void main(String[] args) {
		//for문
		for (int i = 0; i < 100000; i++) {
			System.out.println("카운트! " + i);
		}
	}

}
