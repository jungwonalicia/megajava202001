package 데이터;

public class 기본데이터 {
	public static void main(String[] args) {
		System.out.println("안녕하세요...");
		System.out.println("또 만났네요...");
	}

}
