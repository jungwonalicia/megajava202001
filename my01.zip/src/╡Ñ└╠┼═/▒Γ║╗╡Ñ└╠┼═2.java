package 데이터;

public class 기본데이터2 {

	public static void main(String[] args) {
		// 기본 데이터 저장
		// 정수, 실수 저장
		
		int x = 250; //-21억~21억
		double y = 5.5; //실수
		char z = '한'; //한글자 문자인 경우 '사용
		boolean p = true; //false
		
		System.out.println("x: " + x);
		System.out.println("y: " + y);
		System.out.println("z: " + z);
		System.out.println("p: " + p);
		

	}

}
