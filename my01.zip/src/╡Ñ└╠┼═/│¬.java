package 데이터;

public class 나 {

	public static void main(String[] args) {
		// 기본 데이터 연습
		// 저장공간 => 변수
		// 저장공간이름 => 변수명
		int 나이 = 100; //정수
		double 시력 = 0.8; //실수
		char 성별 = '남'; //문자 한 글자
		boolean 저녁 = true; //논리
		
		//실행(run) 컨트롤 + f11
		//자동완성 
		//syso/sysout + 컨트롤 + 스페이스바
		System.out.println("내 나이는 " + 나이 +"세");
		System.out.println("내 시력은 " + 시력);
		System.out.println("내 성별은 " + 성별);
		System.out.println("내 저녁은 " + 저녁);
		
		

	}

}
