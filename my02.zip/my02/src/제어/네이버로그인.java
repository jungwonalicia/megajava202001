package 제어;

public class 네이버로그인 {

	public static void main(String[] args) {
		int id = 1111;
		//비교 연산자는 조건에 사용되고,
		//비교 연산자의 결과는 무조건 boolean
		if(id == 2222) { //조건이 맞으면(true), 괄호에 있는거 실행!
			System.out.println("로그인 ok...!!!");
		}else { //조건이 안맞으면, 괄호에 있는거 실행!
			System.out.println("로그인 not...!!!");
		} 
	}
}
