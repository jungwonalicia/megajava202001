package 연산;

public class 비교연산 {

	public static void main(String[] args) {
		int n1 = 200;
		int n2 = 100;
		//!!!!!중요!!!!!
		//비교 연산의 결과는? 
		//논리, boolean(true/false)
		System.out.println(n1 >= n2);
		System.out.println(n1 == n2);
	}

}
