package 변수;

public class 데이터 {
	public static void main(String[] args) {
		// 나는 설명쓰는 곳...
		System.out.println("또 만났네요.!!");
		System.out.println("내일 또 쉬어요.!!");
	}
}
