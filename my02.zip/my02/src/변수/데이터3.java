package 변수;

public class 데이터3 {

	public static void main(String[] args) {
		// 컨트롤+쉬프트+f :자동포맷팅(코딩 정리)
		// 한 개이상의 문자들을 저장하기 위해서
		// 부품을 사용해야하지만,
		// 자바에서는 편하게 쓰라고, 기본타입처럼 사용법을 만들어놓았다.
		String hi = "그럼 여러분";
		// 스트링, 문자열

		String name = "홍길동";
		String company = "메가";
	}
}