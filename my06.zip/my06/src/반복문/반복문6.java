package 반복문;

public class 반복문6 {
	public static void main(String[] args) {
		for (int i = 0; i < 10; i++) {
			System.out.print("★" + " ");
		}
	}
}
