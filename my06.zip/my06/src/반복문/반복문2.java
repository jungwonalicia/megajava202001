package 반복문;

public class 반복문2 {

	public static void main(String[] args) {
	
		for (int i = 0; i < 6; i++) {
			//for(초기값; 조건식; 증감식)
			System.out.println(i + ": 반갑습니다.");
		}
	}
}
