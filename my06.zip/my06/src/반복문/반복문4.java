package 반복문;

public class 반복문4 {

	public static void main(String[] args) {
		String sum  = "";
		for (int i = 1; i <= 10000; i++) {
			sum = sum + "축하";
		}
		System.out.println(sum);
	}
}
