package 배열심화;

public class 별100개찍기 {

	public static void main(String[] args) {
		
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 10; j++) {
				//ㅁ + 한자키 => ★
				System.out.print("★");
			}
			System.out.println();
		}
	}
}
