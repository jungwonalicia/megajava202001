package 클래스;

public class 붕어빵틀 {
	
	 String 소;
	 String 두께;
	 
	 public void 붕어빵을먹다() {
		 System.out.println("붕어빵을 먹다.");
	 }
	 
	 public void 붕어빵을담다() {
		System.out.println("붕어빵을 담다.");
	}
	 
	 
	 
	 
	 
}
