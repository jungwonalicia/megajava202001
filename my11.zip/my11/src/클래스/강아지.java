package 클래스;

//강아지가 가지는 일반적인 특징으로 틀을 만들어두면
//강아지 부품이 필요할 때마다 틀로 찍어내듯이
//복사해서 사용하면 된다.
public class 강아지 {
//	 -성질: 색, 나이 => 멤버변수
//	 -동작: 꼬리를 흔들다. 사람을 잘 따른다.
//	       => 멤버메소드
	String color;
	int age;
	
	public void 꼬리를흔들다() {
		System.out.println("꼬리를 흔드는 처리.");
	}
	
	public void 사람을잘따른다() {
		System.out.println("사람을 잘 따르는 처리.");
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
