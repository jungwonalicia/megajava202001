package 클래스;

import javax.swing.JFrame;

public class 그래픽 {

	public static void main(String[] args) {
		JFrame f = new JFrame();
		f.setSize(300, 300);
		f.setTitle("나의 윈도우");
		f.setVisible(true);
	}

}





