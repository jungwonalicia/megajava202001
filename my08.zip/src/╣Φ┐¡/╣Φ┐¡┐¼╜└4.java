package 배열;

public class 배열연습4 {

	public static void main(String[] args) {
		int[] num = new int[1000];
		System.out.println(num.length);
		
		for (int i = 0; i < num.length; i++) {
			num[i] = i;
		}
		
		for (int i = 0; i < num.length; i++) {
			System.out.println(num[i]);
		}
		
		
		
		
		
		
		
		
		
		
		
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
	}
}
